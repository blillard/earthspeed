# __init__.py
from . import windfinder
from .windfinder import *

__all__ = windfinder.__all__

__version__ = "1.0"
